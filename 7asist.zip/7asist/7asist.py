# ♻ coding: utf-8 ♻ 
# ♻﴾sᴀмuᴅʀᴀ____ʙoтs﴿♻
# ♻cʀᴇᴀтoʀ: sᴀмuᴅʀᴀ♻
from BANGSAMUDRA import *
from akad.ttypes import *
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from multiprocessing import Pool, Process
from time import sleep
import pytz, datetime, pafy, time, timeit, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, wikipedia, urllib.parse
from datetime import timedelta, date
from datetime import datetime
import html5lib
from random import randint
import requests,json,urllib3
import pyimgflip
_session = requests.session()
botStart = time.time()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#-----------------------------------------------------------------------
SAMUDRABOTS ="ANDROIDLITE\t2.14.0\tAndroid OS\t5.1.1"
#-----------------------------------------------------------------------
samudra = LINE("u3fd6ebe0ce4589d6c57dcf6b162978f5:aWF0OiAxNTk5Mjc1NTc3MDkxCg==..ROB0z47hkMX2Mx1fhtwJGwPczWY=",appName=SAMUDRABOTS)
samudra.log("Auth Token : " + str(samudra.authToken))

samudra1 = LINE("u9b6ba01232e269b732a45c454a82c909:aWF0OiAxNTk5MTkzOTk2NjA1Cg==..YWZujc+kABEjAFU/WEpKrTto7WM=",appName=SAMUDRABOTS)
samudra1.log("Auth Token : " + str(samudra1.authToken))

samudra2 = LINE("ubdfc3cc405324fd84ffda75387b266aa:aWF0OiAxNTk5MjA5NDk5ODIwCg==..LSPwM76pO7sk5o8IvE2as4GpwHU=",appName=SAMUDRABOTS)
samudra2.log("Auth Token : " + str(samudra2.authToken))

samudra3 = LINE("u2088e3e9bb9ec06ade50cf9808f2f541:aWF0OiAxNTk5MjE3NzUzNzM1Cg==..+szFJ6VO42KVCAsazNBwxIVC2gQ=",appName=SAMUDRABOTS)
samudra3.log("Auth Token : " + str(samudra3.authToken))

samudra4 = LINE("u16629eaec0ec30fef14252f7a823e4ed:aWF0OiAxNTk5MjIyMTM3MjIxCg==..Zkv5L+HSxOMIevwOe1EjaKRPSRU=",appName=SAMUDRABOTS)
samudra4.log("Auth Token : " + str(samudra4.authToken))

samudra5 = LINE("u2db6a9bbc502fed47e6773044b085643:aWF0OiAxNTg1OTA4NjI4NDI3Cg==..0w2wKGDzlNaUrnNogCzn3/g0WDc=",appName=SAMUDRABOTS)
samudra5.log("Auth Token : " + str(samudra5.authToken))

samudrajs1 = LINE("uaebb8a566ff3a885d76276be531ff758:aWF0OiAxNTY1MzM3MzExMDAzCg==..FXSz9+P8RAvC8QC5JA546V3kkC8=",appName=SAMUDRABOTS)
samudrajs1.log("Auth Token : " + str(samudrajs1.authToken))

samudrajs2 = LINE("u23c82fcf97686f32f4ba8fef2386f485:aWF0OiAxNTc1ODY3MzQxNzcyCg==..5h3qS6Zuu+EPsWOVfpoW2OM78fY=",appName=SAMUDRABOTS)
samudrajs2.log("Auth Token : " + str(samudrajs2.authToken))

print("---LOGIN DI SAMUDRA SUCCES---")
#-----------------------------------------------------------------------
stickeropen = codecs.open("sticker4.json","r","utf-8")
jiranstick = json.load(stickeropen)
paja = codecs.open("zeuszxadmin.json","r","utf-8")
zeuszxadmin = json.load(paja)
#------------------------------------------------------------------------
oepoll = OEPoll(samudra)
call = samudra
creator = ["u2effeeea6ac18bcb6dc2bb1d66bc828d"]
owner = ["u2effeeea6ac18bcb6dc2bb1d66bc828d"]
admin = ["u2effeeea6ac18bcb6dc2bb1d66bc828d"]
staff = ["u2effeeea6ac18bcb6dc2bb1d66bc828d"]
admin1 = ["u2effeeea6ac18bcb6dc2bb1d66bc828d"]
selfmid = samudra.getProfile().mid
Amid = samudra1.getProfile().mid
Bmid = samudra2.getProfile().mid
Cmid = samudra3.getProfile().mid
Dmid = samudra4.getProfile().mid
Emid = samudra5.getProfile().mid
Xmid = samudrajs1.getProfile().mid
Zmid = samudrajs2.getProfile().mid
SASAK = [samudra,samudra1,samudra2,samudra3,samudra4,samudra5,samudrajs1,samudrajs2]
LOMBOK = [samudra1,samudra2,samudra3,samudra4,samudra5,samudrajs1,samudrajs2]
Semeton = [selfmid,Amid,Bmid,Cmid,Dmid,Emid,Xmid,Zmid]
Ntb = admin + staff

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
protectantijs = []
ghost = []

welcome = []
left = []

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':True,
    'autoAdd':True,
    'left':False,
    'qr':False,
    'inv':False,
    'autoRead':False,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":True,
    "Mentionkick":False,
    "welcomeOn":False,
    "leaveOn":False,
    "sticker":False,
    "selfbot":True,
    "setsticker":{
            "name": "",
            "status":False
            },
    "mention":"Ngintip lagi tak colok",
    "Respontag":"Nikah yuk",
    "welcome":"Selamat datang & semoga betah coy",
    "leave":"Selamat tinggal & semoga sampai tujuan amin",
    "comment":"Like like & like Samudra ",
    "message":"╭───────────────\n│╭──────────────\n│├• ᴛᴇʀɪᴍᴀᴋᴀsɪʜ\n│├• sᴀмuᴅʀᴀ\n│╰──────────────\n├──•〔 ᴏ ᴘ ᴇ ɴ ʀ ᴇ ɴ ᴛ ᴀ ʟ 〕\n│╭──────────────\n│├─•  sᴇʟғʙᴏᴛ :\n││( 𝟏 )• ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n││( 𝟐 )• ɴᴏ ᴛᴇᴍᴘʟᴀᴛᴇ\n│├─•  ᴘʀᴏᴛᴇᴄᴛ / ᴡᴀʀ :\n││( 𝟏 )• 𝟑 ᴀssɪsᴛ\n││( 𝟐 )• 𝟓 ᴀssɪsᴛ\n││( 𝟑 )• 𝟕 ᴀssɪsᴛ\n││( 𝟒 )• ᴄʟɪᴇɴᴛ ᴘʀᴏᴛᴇᴄᴛ\n│╰──────────────\n├──•〔 sᴇʟʟ   ᴛʜᴇ   sᴄʀɪᴘᴛ 〕\n│╭──────────────\n││( 𝟏 )• ʜᴇʟᴘᴇʀs\n││( 𝟐 )• sʙ ᴡᴀʀ\n││( 𝟑 )• sʙ ᴘʀᴏᴛᴇᴄᴛ\n││( 𝟒 )• ᴄʟ/ᴄʟɪᴇɴᴛ\n││( 𝟓 )• sʙ ғᴜʟʟ ᴛᴇᴍᴘʟᴀᴛᴇ\n│╰──────────────\n│ ན ᴄʀ : line://ti/p/~samudrabots.py\n│ ན ᴄʀ : line://ti/p/~samudrabots.py\n╰───────────────",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = samudra.getGroup(to)
        textx = "「 Member~Desah 」\n\n1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "「✭」{}. ".format(str(no))
            else:
                textx += "\n「 Banyaknya {} Oiy 」".format(str(len(mid)))
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Hello ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(samudra.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Hello ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = samudra.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(samudra.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "「 Respon Leave 」\nNah Loo ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = samudra.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(samudra.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        samudra.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = samudra.getAllContactIds()
        gid = samudra.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"◐ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" Wib\n⏩ Group : "+str(len(gid))+"\n⏩ Teman : "+str(len(teman))+"\n⏩ Expired : In "+hari+"\n⏩ Version : ANTIJS2\n⏩ Tanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n⏩ Runtime : \n • "+bot
        samudra.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        samudra.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "▬▬▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬▬\n" + \
                  "╔══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"+\
                  "║👻➸ " + key + "Help\n" + \
                  "║👻➸ " + key + "Help2\n" + \
                  "║👻➸ " + key + "Me\n" + \
                  "║👻➸ " + key + "Mid「@」\n" + \
                  "║👻➸ " + key + "Mybot\n" + \
                  "║👻➸ " + key + "Respon\n" + \
                  "║👻➸ " + key + "Status\n" + \
                  "║👻➸ " + key + "About\n" + \
                  "║👻➸ " + key + "Restart\n" + \
                  "║👻➸ " + key + "Runtime\n" + \
                  "║👻➸ " + key + "Creator\n" + \
                  "║👻➸ " + key + "Speed/Sp\n" + \
                  "║👻➸ " + key + "Tagall/All/Sayang\n" + \
                  "║👻➸ " + key + "In\n" + \
                  "║👻➸ " + key + "Out\n" + \
                  "║👻➸ " + key + "Invite\n" + \
                  "║👻➸ " + key + "Inviteme\n" + \
                  "║👻➸ " + key + "Leaveall\n" + \
                  "║👻➸ " + key + "Byeme\n" + \
                  "║👻➸ " + key + "Sider「on/off」\n" + \
                  "║👻➸ " + key + "Ginfo\n" + \
                  "║👻➸ " + key + "Open\n" + \
                  "║👻➸ " + key + "Close\n" + \
                  "║👻➸ " + key + "Url\n" + \
                  "║👻➸ " + key + "Gruplist\n" + \
                  "║👻➸ " + key + "Remove chat\n" + \
                  "║👻➸ " + key + "Broadcast:「Text」\n" + \
                  "║👻➸ " + key + "Setkey「New Key」\n" + \
                  "║👻➸ " + key + "Mykey\n" + \
                  "║👻➸ " + key + "Resetkey\n" + \
                  "╠══[ Kicker ]\n" + \
                  "║👻➸ " + key + "Kick「@」\n" + \
                  "║👻➸ " + key + "Vkick「@」\n" + \
                  "║👻➸ " + key + "Cancelall \n" + \
                  "║👻➸ " + key + "Clean \n" + \
                  "║👻➸ " + key + "Nk 「@」\n" + \
                  "╠══[ ᴍᴇᴅɪᴀ ]\n" + \
                  "║👻➸ " + key + "Spamtag:「jumlahnya」\n" + \
                  "║👻➸ " + key + "Spamtag\n" + \
                  "║👻➸ " + key + "Spamcall:「jumlahnya」\n" + \
                  "║👻➸ " + key + "Spamcall\n" + \
                  "║👻➸ " + key + "Ytmp4:「Judul Video」\n" + \
                  "╠══[ protect ]\n" + \
                  "║👻➸ " + key + "Allpro「on/off」\n" + \
                  "║👻➸ " + key + "Protecturl「on/off」\n" + \
                  "║👻➸ " + key + "Protectjoin「on/off」\n" + \
                  "║👻➸ " + key + "Protectkick「on/off」\n" + \
                  "║👻➸ " + key + "Protectinvite「on/off」\n" + \
                  "║👻➸ " + key + "Protectcancel「on/off」\n" + \
                  "║👻➸ " + key + "Antijs「on/off」\n" + \
                  "╠══[ Set user ]\n" + \
                  "║👻➸ " + key + "Autojoin「on/off」\n" + \
                  "╠══[ Set Admin ]\n" + \
                  "║👻➸ " + key + "Self「on/off」\n" + \
                  "║👻➸ " + key + "Staff:on\n" + \
                  "║👻➸ " + key + "Staff:repeat\n" + \
                  "║👻➸ " + key + "Admin:on\n" + \
                  "║👻➸ " + key + "Admin:repeat\n" + \
                  "║👻➸ " + key + "Staffadd「@」\n" + \
                  "║👻➸ " + key + "Staffdell「@」\n" + \
                  "║👻➸ " + key + "Adminadd「@」\n" + \
                  "║👻➸ " + key + "Admindell「@」\n" + \
                  "║👻➸ " + key + "Refresh\n" + \
                  "║👻➸ " + key + "Listbot\n" + \
                  "║👻➸ " + key + "Listadmin\n" + \
                  "║👻➸ " + key + "Listprotect\n" + \
                  "╚══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n" + \
                  "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "\nιɴԍᴀт ᴅι「 Refresh 」sᴇsuᴅᴀн ᴘᴀκᴀι\n"
    return helpMessage

def helpbot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "╔══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"+\
                  "║➸ " + key + "Blc\n" + \
                  "║➸ " + key + "Ban:on\n" + \
                  "║➸ " + key + "Unban:on\n" + \
                  "║➸ " + key + "Ban「@」\n" + \
                  "║➸ " + key + "Unban「@」\n" + \
                  "║➸ " + key + "Talkban「@」\n" + \
                  "║➸ " + key + "Untalkban「@」\n" + \
                  "║➸ " + key + "Talkban:on\n" + \
                  "║➸ " + key + "Untalkban:on\n" + \
                  "║➸ " + key + "Banlist\n" + \
                  "║➸ " + key + "Talkbanlist\n" + \
                  "║➸ " + key + "Ceban\n" + \
                  "║➸ " + key + "Refresh\n" + \
                  "╠══[ Cek Seting ]\n" + \
                  "║➸ " + key + "Cek sider\n" + \
                  "║➸ " + key + "Cek spam\n" + \
                  "║➸ " + key + "Cek pesan \n" + \
                  "║➸ " + key + "Cek respon \n" + \
                  "║➸ " + key + "Cek leave\n" + \
                  "║➸ " + key + "Cek welcome\n" + \
                  "║➸ " + key + "Set sider:「Text」\n" + \
                  "║➸ " + key + "Set spam:「Text」\n" + \
                  "║➸ " + key + "Set pesan:「Text」\n" + \
                  "║➸ " + key + "Set respon:「Text」\n" + \
                  "║➸ " + key + "Set leave:「Text」\n" + \
                  "║➸ " + key + "Set welcome:「Text」\n" + \
                  "║➸ " + key + "Setsticker meme「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker respon「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker sider「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker welcome「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker leave「kirim photo」\n" + \
                  "║➸ " + key + "Myname:「Nama」\n" + \
                  "║➸ " + key + "Gift:「Mid korban」「Jumlah」\n" + \
                  "║➸ " + key + "Spam:「Mid korban」「Jumlah」\n" + \
                  "╚══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n" + \
                  "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "\nιɴԍᴀт ᴅι「 Refresh 」sᴇsuᴅᴀн ᴘᴀκᴀι\n"
    return helpMessage1

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
#---------------PRO QR----------------------------------------------------------
        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if random.choice(LOMBOK).getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                            X = random.choice(LOMBOK).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(LOMBOK).updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass
            if wait["qr"] == True:
                try:
                    if random.choice(LOMBOK).getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                            X = random.choice(LOMBOK).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(LOMBOK).updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass
#---------------AUTO LEFT-------------------------------------------------------
        if op.type == 13:
            if selfmid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra.acceptGroupInvitation(op.param1)
                        ginfo = samudra.getGroup(op.param1)
                        samudra.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra.leaveGroup(op.param1)
                    else:
                        samudra.acceptGroupInvitation(op.param1)
                        ginfo = samudra.getGroup(op.param1)
                        samudra.sendMessage(op.param1,"Hai " + str(ginfo.name))
#---------------AUTO JOIN-------------------------------------------------------
        if op.type == 13:
            if selfmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra.acceptGroupInvitation(op.param1)
                        ginfo = samudra.getGroup(op.param1)
                        samudra.sendMessage(op.param1,"Anda Bukan Admin")
                        samudra.leaveGroup(op.param1)
                    else:
                        samudra.acceptGroupInvitation(op.param1)
        if op.type == 13:
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra1.acceptGroupInvitation(op.param1)
                        ginfo = samudra1.getGroup(op.param1)
                        samudra1.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra1.leaveGroup(op.param1)
                    else:
                        samudra1.acceptGroupInvitation(op.param1)
                        group = samudra1.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    samudra1.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra2.acceptGroupInvitation(op.param1)
                        ginfo = samudra2.getGroup(op.param1)
                        samudra2.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra2.leaveGroup(op.param1)
                    else:
                        samudra2.acceptGroupInvitation(op.param1)
                        group = samudra2.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    samudra2.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra3.acceptGroupInvitation(op.param1)
                        ginfo = samudra3.getGroup(op.param1)
                        samudra3.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra3.leaveGroup(op.param1)
                    else:
                        samudra3.acceptGroupInvitation(op.param1)
                        group = samudra3.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    samudra3.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Dmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra4.acceptGroupInvitation(op.param1)
                        ginfo = samudra4.getGroup(op.param1)
                        samudra4.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra4.leaveGroup(op.param1)
                    else:
                        samudra4.acceptGroupInvitation(op.param1)
                        group = samudra4.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    samudra4.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Emid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                        samudra5.acceptGroupInvitation(op.param1)
                        ginfo = samudra5.getGroup(op.param1)
                        samudra5.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        samudra5.leaveGroup(op.param1)
                    else:
                        samudra5.acceptGroupInvitation(op.param1)
                        group = samudra5.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    samudra5.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
#---------------PRO INVITE------------------------------------------------------
        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in anakkuadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Semeton and _mid not in owner and _mid not in admin and _mid not in zeuszxadmin["staff"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Semeton and _mid not in owner and _mid not in admin and _mid not in zeuszxadmin["staff"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        group = random.choice(LOMBOK).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        group = random.choice(LOMBOK).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Semeton and _mid not in owner and _mid not in admin and _mid not in zeuszxadmin["staff"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
            if wait["inv"] == True:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Semeton and _mid not in owner and _mid not in admin and _mid not in zeuszxadmin["staff"]:
                                random.choice(LOMBOK).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------PRO JOIN--------------------------------------------------------
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = samudra1.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        samudra1.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = samudra2.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        samudra2.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = samudra3.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        samudra3.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = samudra4.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        samudra4.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = samudra5.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        samudra5.kickoutFromGroup(op.param1,[_mid])
#---------------MEMBER MASUK----------------------------------------------------
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Semeton:
                    pass
                ginfo = samudra.getGroup(op.param1)
                contact = samudra.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                samudra.sendImageWithURL(op.param1, image)
                samudra.sendMessage(op.param1, None, contentMetadata= jiranstick["welcome"], contentType=7)
#---------------MEMBER LEFT-----------------------------------------------------
        if op.type == 15:
            if wait["left"] == True:
                if op.param2 in Semeton:
                    pass
                ginfo = samudra.getGroup(op.param1)
                leaveMembers(op.param1, [op.param2])
                samudra.sendMessage(op.param1, None, contentMetadata= jiranstick["leave"], contentType=7)
        if op.type == 15:
            if op.param2 in Zmid:
                try:
                    samudra1.findAndAddContactsByMid(Zmid)
                    samudra1.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        samudra2.findAndAddContactsByMid(Zmid)
                        samudra2.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        try:
                            samudra3.findAndAddContactsByMid(Zmid)
                            samudra3.inviteIntoGroup(op.param1,[Zmid])
                        except:
                            try:
                                samudra4.findAndAddContactsByMid(Zmid)
                                samudra4.inviteIntoGroup(op.param1,[Zmid])
                            except:
                                try:
                                    samudra5.findAndAddContactsByMid(Zmid)
                                    samudra5.inviteIntoGroup(op.param1,[Zmid])
                                except:
                                    pass
            if op.param2 in Xmid:
                try:
                    samudra1.findAndAddContactsByMid(Xmid)
                    samudra1.inviteIntoGroup(op.param1,[Xmid])
                except:
                    try:
                        samudra2.findAndAddContactsByMid(Xmid)
                        samudra2.inviteIntoGroup(op.param1,[Xmid])
                    except:
                        try:
                            samudra3.findAndAddContactsByMid(Xmid)
                            samudra3.inviteIntoGroup(op.param1,[Xmid])
                        except:
                            try:
                                samudra4.findAndAddContactsByMid(Xmid)
                                samudra4.inviteIntoGroup(op.param1,[Xmid])
                            except:
                                try:
                                    samudra5.findAndAddContactsByMid(Xmid)
                                    samudra5.inviteIntoGroup(op.param1,[Xmid])
                                except:
                                    pass
#---------------PRO JOIN--------------------------------------------------------
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------AUTO ADD--------------------------------------------------------
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        samudra.sendMessage(op.param1, wait["message"])
#---------------PRO KICK--------------------------------------------------------
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    try:
                        random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------PRO CANCEL------------------------------------------------------
        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin and op.param2 not in zeuszxadmin["staff"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                           pass
#------- Jika Bots Di Kick Atau Di Cancel -------------------------------------------------------
        if op.type == 19 or op.type == 32:
            if selfmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra1.findAndAddContactsByMid(selfmid)
                        samudra1.kickoutFromGroup(op.param1,[op.param2])
                        samudra1.inviteIntoGroup(op.param1,[op.param3])
                        samudra.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            samudra2.findAndAddContactsByMid(selfmid)
                            samudra2.kickoutFromGroup(op.param1,[op.param2])
                            samudra2.inviteIntoGroup(op.param1,[op.param3])
                            samudra.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                samudra3.findAndAddContactsByMid(selfmid)
                                samudra3.kickoutFromGroup(op.param1,[op.param2])
                                samudra3.inviteIntoGroup(op.param1,[op.param3])
                                samudra.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    samudra4.findAndAddContactsByMid(selfmid)
                                    samudra4.kickoutFromGroup(op.param1,[op.param2])
                                    samudra4.inviteIntoGroup(op.param1,[op.param3])
                                    samudra.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        samudra5.findAndAddContactsByMid(selfmid)
                                        samudra5.kickoutFromGroup(op.param1,[op.param2])
                                        samudra5.inviteIntoGroup(op.param1,[op.param3])
                                        samudra.acceptGroupInvitation(op.param1)
                                    except:
                                        try:                                                                                                        	
                                            samudrajs1.acceptGroupInvitation(op.param1)
                                            samudrajs2.acceptGroupInvitation(op.param1)
                                            samudrajs2.kickoutFromGroup(op.param1,[op.param2])
                                            G = samudrajs1.getGroup(op.param1)
                                            G.preventedJoinByTicket = False
                                            samudrajs1.updateGroup(G)
                                            Ticket = samudrajs1.reissueGroupTicket(op.param1)
                                            samudra.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudrajs1.leaveGroup(op.param1)
                                            samudrajs2.leaveGroup(op.param1)
                                            G = samudra.getGroup(op.param1)
                                            G.preventedJoinByTicket = True
                                            samudra.updateGroup(G)
                                        except:
                                             pass
                return

            if Amid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra2.findAndAddContactsByMid(Amid)
                        samudra2.kickoutFromGroup(op.param1,[op.param2])
                        samudra2.inviteIntoGroup(op.param1,[op.param3])
                        samudra1.acceptGroupInvitation(op.param1)
                        group = samudra1.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                samudra1.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            samudra3.findAndAddContactsByMid(Amid)
                            samudra3.kickoutFromGroup(op.param1,[op.param2])
                            samudra3.inviteIntoGroup(op.param1,[op.param3])
                            samudra1.acceptGroupInvitation(op.param1)
                            group = samudra1.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    samudra1.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                samudra4.findAndAddContactsByMid(Amid)
                                samudra4.kickoutFromGroup(op.param1,[op.param2])
                                samudra4.inviteIntoGroup(op.param1,[op.param3])
                                samudra1.acceptGroupInvitation(op.param1)
                                group = samudra1.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        samudra1.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    samudra5.findAndAddContactsByMid(Amid)
                                    samudra5.kickoutFromGroup(op.param1,[op.param2])
                                    samudra5.inviteIntoGroup(op.param1,[op.param3])
                                    samudra1.acceptGroupInvitation(op.param1)
                                    group = samudra1.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            samudra1.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                        random.choice(LOMBOK).inviteIntoGroup(op.param1,[op.param3])
                                        samudra2.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            samudrajs1.acceptGroupInvitation(op.param1)
                                            samudrajs2.acceptGroupInvitation(op.param1)
                                            samudrajs2.kickoutFromGroup(op.param1,[op.param2])
                                            G = samudrajs1.getGroup(op.param1)
                                            G.preventedJoinByTicket = False
                                            samudrajs1.updateGroup(G)
                                            Ticket = samudrajs1.reissueGroupTicket(op.param1)
                                            samudra.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudra5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            samudrajs1.leaveGroup(op.param1)
                                            samudrajs2.leaveGroup(op.param1)
                                            G = samudra.getGroup(op.param1)
                                            G.preventedJoinByTicket = True
                                            samudra.updateGroup(G)
                                        except:
                                            pass
                return

            if Bmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra3.findAndAddContactsByMid(Bmid)
                        samudra3.kickoutFromGroup(op.param1,[op.param2])
                        samudra3.inviteIntoGroup(op.param1,[op.param3])
                        samudra2.acceptGroupInvitation(op.param1)
                        group = samudra2.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                samudra2.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            samudra4.findAndAddContactsByMid(Bmid)
                            samudra4.kickoutFromGroup(op.param1,[op.param2])
                            samudra4.inviteIntoGroup(op.param1,[op.param3])
                            samudra2.acceptGroupInvitation(op.param1)
                            group = samudra2.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    samudra2.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                samudra5.findAndAddContactsByMid(Bmid)
                                samudra5.kickoutFromGroup(op.param1,[op.param2])
                                samudra5.inviteIntoGroup(op.param1,[op.param3])
                                samudra2.acceptGroupInvitation(op.param1)
                                group = samudra2.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        samudra2.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                    random.choice(LOMBOK).inviteIntoGroup(op.param1,[op.param3])
                                    samudra3.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        samudrajs1.acceptGroupInvitation(op.param1)
                                        samudrajs2.acceptGroupInvitation(op.param1)
                                        samudrajs2.kickoutFromGroup(op.param1,[op.param2])
                                        G = samudrajs1.getGroup(op.param1)
                                        G.preventedJoinByTicket = False
                                        samudrajs1.updateGroup(G)
                                        Ticket = samudrajs1.reissueGroupTicket(op.param1)
                                        samudra.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudra1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudra2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudra3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudra4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudra5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        samudrajs1.leaveGroup(op.param1)
                                        samudrajs2.leaveGroup(op.param1)
                                        G = samudra.getGroup(op.param1)
                                        G.preventedJoinByTicket = True
                                        samudra.updateGroup(G)
                                    except:
                                        pass
                return

            if Cmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra4.findAndAddContactsByMid(Cmid)
                        samudra4.kickoutFromGroup(op.param1,[op.param2])
                        samudra4.inviteIntoGroup(op.param1,[op.param3])
                        samudra3.acceptGroupInvitation(op.param1)
                        group = samudra3.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                samudra3.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            samudra5.findAndAddContactsByMid(Cmid)
                            samudra5.kickoutFromGroup(op.param1,[op.param2])
                            samudra5.inviteIntoGroup(op.param1,[op.param3])
                            samudra3.acceptGroupInvitation(op.param1)
                            group = samudra3.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    samudra3.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                                random.choice(LOMBOK).inviteIntoGroup(op.param1,[op.param3])
                                samudra4.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    samudrajs1.acceptGroupInvitation(op.param1)
                                    samudrajs2.acceptGroupInvitation(op.param1)
                                    samudrajs2.kickoutFromGroup(op.param1,[op.param2])
                                    G = samudrajs1.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    samudrajs1.updateGroup(G)
                                    Ticket = samudrajs1.reissueGroupTicket(op.param1)
                                    samudra.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudra1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudra2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudra3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudra4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudra5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    samudrajs1.leaveGroup(op.param1)
                                    samudrajs2.leaveGroup(op.param1)
                                    G = samudra.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    samudra.updateGroup(G)
                                except:
                                    pass
                return

            if Dmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra5.findAndAddContactsByMid(Dmid)
                        samudra5.kickoutFromGroup(op.param1,[op.param2])
                        samudra5.inviteIntoGroup(op.param1,[op.param3])
                        samudra4.acceptGroupInvitation(op.param1)
                        group = samudra4.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                samudra4.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(LOMBOK).inviteIntoGroup(op.param1,[op.param3])
                            samudra5.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                samudrajs1.acceptGroupInvitation(op.param1)
                                samudrajs2.acceptGroupInvitation(op.param1)
                                samudrajs2.kickoutFromGroup(op.param1,[op.param2])
                                G = samudrajs1.getGroup(op.param1)
                                G.preventedJoinByTicket = False
                                samudrajs1.updateGroup(G)
                                Ticket = samudrajs1.reissueGroupTicket(op.param1)
                                samudra.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudra1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudra2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudra3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudra4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudra5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                samudrajs1.leaveGroup(op.param1)
                                samudrajs2.leaveGroup(op.param1)
                                G = samudra.getGroup(op.param1)
                                G.preventedJoinByTicket = True
                                samudra.updateGroup(G)
                            except:
                                pass

                return

            if Zmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra1.findAndAddContactsByMid(Zmid)
                        samudra1.kickoutFromGroup(op.param1,[op.param2])
                        samudra1.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            samudra2.findAndAddContactsByMid(Zmid)
                            samudra2.kickoutFromGroup(op.param1,[op.param2])
                            samudra2.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                samudra3.findAndAddContactsByMid(Zmid)
                                samudra3.kickoutFromGroup(op.param1,[op.param2])
                                samudra3.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    samudra4.findAndAddContactsByMid(Zmid)
                                    samudra4.kickoutFromGroup(op.param1,[op.param2])
                                    samudra4.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        samudra5.findAndAddContactsByMid(Zmid)
                                        samudra5.kickoutFromGroup(op.param1,[op.param2])
                                        samudra5.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        pass

                return

            if Xmid in op.param3:
                if op.param2 in Semeton:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra1.findAndAddContactsByMid(Xmid)
                        samudra1.kickoutFromGroup(op.param1,[op.param2])
                        samudra1.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            samudra2.findAndAddContactsByMid(Xmid)
                            samudra2.kickoutFromGroup(op.param1,[op.param2])
                            samudra2.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                samudra3.findAndAddContactsByMid(Xmid)
                                samudra3.kickoutFromGroup(op.param1,[op.param2])
                                samudra3.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    samudra4.findAndAddContactsByMid(Xmid)
                                    samudra4.kickoutFromGroup(op.param1,[op.param2])
                                    samudra4.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        samudra5.findAndAddContactsByMid(Xmid)
                                        samudra5.kickoutFromGroup(op.param1,[op.param2])
                                        samudra5.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        pass

                return

            if op.param3 in admin1:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra1.kickoutFromGroup(op.param1,[op.param2])
                        ls = samudra.getContact(admin1).mid
                        samudra.findAndAddContactsByMid(ls)
                        samudra.inviteIntoGroup(op.param1,[ls])
                    except:
                        try:
                            samudra2.kickoutFromGroup(op.param1,[op.param2])
                            ls = samudra2.getContact(admin1).mid
                            samudra1.findAndAddContactsByMid(ls)
                            samudra1.inviteIntoGroup(op.param1,[ls])
                        except:
                            try:
                                samudra3.kickoutFromGroup(op.param1,[op.param2])
                                ls = samudra2.getContact(admin1).mid
                                samudra2.findAndAddContactsByMid(ls)
                                samudra2.inviteIntoGroup(op.param1,[ls])
                            except:
                                try:
                                    samudra4.kickoutFromGroup(op.param1,[op.param2])
                                    ls = samudra3.getContact(admin1).mid
                                    samudra3.findAndAddContactsByMid(ls)
                                    samudra3.inviteIntoGroup(op.param1,[ls])
                                except:
                                    try:
                                        samudra5.kickoutFromGroup(op.param1,[op.param2])
                                        ls = samudra4.getContact(admin1).mid
                                        samudra4.findAndAddContactsByMid(ls)
                                        samudra4.inviteIntoGroup(op.param1,[ls])
                                    except:
                                        pass
                return

            if op.param3 in admin:
                if op.param2 not in Semeton and op.param2 not in owner and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        samudra1.kickoutFromGroup(op.param1,[op.param2])
                        samudra.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                        samudra.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                    except:
                        try:
                            samudra2.kickoutFromGroup(op.param1,[op.param2])
                            samudra2.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                            samudra2.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                        except:
                            try:
                                samudra3.kickoutFromGroup(op.param1,[op.param2])
                                samudra3.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                samudra3.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                            except:
                                try:
                                    samudra5.kickoutFromGroup(op.param1,[op.param2])
                                    samudra5.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                    samudra5.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                except:
                                    try:
                                        samudra4.kickoutFromGroup(op.param1,[op.param2])
                                        samudra4.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                        samudra4.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                    except:
                                        pass
                return
#-------------------------------------------------------------------------------
        if op.type == 55:
            try:
                if op.param1 in Setmain["ARreadPoint"]:
                   if op.param2 in Setmain["ARreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["ARreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = samudra.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = samudra.getContact(op.param2)
                        image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        samudra.sendImageWithURL(op.param1, image)
                        samudra.sendMessage(op.param1, None, contentMetadata= jiranstick["sider"], contentType=7)

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 55:
            if op.param3 in wait["blacklist"]:
                random.choice(LOMBOK).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Semeton:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(LOMBOK).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          pass
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in selfmid:
                           samudra.sendMessage(msg.to, wait["Respontag"])
                           samudra.sendMessage(msg.to, None, contentMetadata= jirantick["respon"], contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in selfmid:
                           samudra.mentiontag(msg.to,[msg._from])
                           samudra.sendMessage(msg.to, "Jangan tag saya....")
                           samudra.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,"「Cek ID Sticker」\n❧STKID : " + msg.contentMetadata["STKID"] + "\n❧STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n❧STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = samudra.getContact(msg.contentMetadata["mid"])
                        path = samudra.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        samudra.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        samudra.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    samudra.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = samudra.getContact(msg.contentMetadata["mid"])
                        path = samudra.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        samudra.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        samudra.sendImageWithURL(msg.to, image)
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Semeton:
                        samudra.sendMessage(msg.to,"Contact itu sudah jadi anggota bot")
                        wait["addbots"] = True
                    else:
                        Semeton.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke anggota bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Semeton:
                        Semeton.remove(msg.contentMetadata["mid"])
                        samudra.sendMessage(msg.to,"Berhasil menghapus dari anggota bot")
                    else:
                        wait["dellbots"] = True
                        samudra.sendMessage(msg.to,"Contact itu bukan anggota bot bot")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in zeuszxadmin["staff"]:
                        samudra.sendMessage(msg.to,"was staff")
                    else:
                        anakkuadmin["staff"][msg.contentMetadata["mid"]] = True
                        f=codecs.open('zeuszxadmin.json','w','utf-8')
                        json.dump(zeuszxadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                        samudra.sendMessage(msg.to,"succes add staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in zeuszxadmin["staff"]:
                        del zeuszxadmin["staff"][msg.contentMetadata["mid"]]
                        f=codecs.open('zeuszxadmin.json','w','utf-8')
                        json.dump(zeuszxadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                        samudra.sendMessage(msg.to,"Succes remove staff")
                    else:
                        samudra.sendMessage(msg.to,"Contact not in list staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        samudra.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        samudra.sendMessage(msg.to,"Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        samudra.sendMessage(msg.to,"Berhasil menghapus dari admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        samudra.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        samudra.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        samudra.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        samudra.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        samudra.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        samudra.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        samudra.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        samudra.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = samudra.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            samudra.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = samudra.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     samudra.updateGroupPicture(msg.to, path)
                     samudra.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if selfmid in Setmain["ARfoto"]:
                            path = samudra.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][selfmid]
                            samudra.updateProfilePicture(path)
                            samudra.sendMessage(msg.to,"succes change photo")

               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["setsticker"]["status"] == True:
                        jiranstick[wait["setsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"],"STKVER":msg.contentMetadata["STKVER"]}
                        f = codecs.open("sticker4.json","w","utf-8")
                        json.dump(jiranstick, f, sort_keys=True, indent=4, ensure_ascii=False)
                        samudra.sendMessage(msg.to, "Berhasil mengganti sticker {}".format(str(wait["setsticker"]["name"])))
                        wait["setsticker"]["status"] = False
                        wait["setsticker"]["name"] = ""

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["ARfoto"]:
                            path = samudra1.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Amid]
                            samudra1.updateProfilePicture(path1)
                            samudra1.sendMessage(msg.to,"succes change photo")
                        elif Bmid in Setmain["ARfoto"]:
                            path = samudra2.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Bmid]
                            samudra2.updateProfilePicture(path2)
                            samudra2.sendMessage(msg.to,"succes change photo")
                        elif Cmid in Setmain["ARfoto"]:
                            path = samudra3.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Cmid]
                            samudra3.updateProfilePicture(path3)
                            samudra3.sendMessage(msg.to,"succes change photo")
                        elif Dmid in Setmain["ARfoto"]:
                            path = samudra4.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Dmid]
                            samudra4.updateProfilePicture(path4)
                            samudra4.sendMessage(msg.to,"succes change photo")
                        elif Emid in Setmain["ARfoto"]:
                            path = samudra5.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Emid]
                            samudra5.updateProfilePicture(path5)
                            samudra5.sendMessage(msg.to,"succes change photo")
                        elif Xmid in Setmain["ARfoto"]:
                            path = samudrajs1.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Xmid]
                            samudrajs1.updateProfilePicture(path6)
                            samudrajs1.sendMessage(msg.to,"succes change photo")
                        elif Zmid in Setmain["ARfoto"]:
                            path = samudrajs2.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Zmid]
                            samudrajs2.updateProfilePicture(path7)
                            samudrajs2.sendMessage(msg.to,"succes change photo")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = samudra1.downloadObjectMsg(msg_id)
                     path2 = samudra2.downloadObjectMsg(msg_id)
                     path3 = samudra3.downloadObjectMsg(msg_id)
                     path4 = samudra4.downloadObjectMsg(msg_id)
                     path5 = samudra5.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     samudra1.updateProfilePicture(path1)
                     samudra1.sendMessage(msg.to, "succes change photo")
                     samudra2.updateProfilePicture(path2)
                     samudra2.sendMessage(msg.to, "succes change photo")
                     samudra3.updateProfilePicture(path3)
                     samudra3.sendMessage(msg.to, "succes change photo")
                     samudra4.updateProfilePicture(path4)
                     samudra4.sendMessage(msg.to, "succes change photo")
                     samudra5.updateProfilePicture(path5)
                     samudra5.sendMessage(msg.to, "succes change photo")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        samudra.sendChatChecked(msg.to, msg_id)
                        samudra1.sendChatChecked(msg.to, msg_id)
                        samudra2.sendChatChecked(msg.to, msg_id)
                        samudra3.sendChatChecked(msg.to, msg_id)
                        samudra4.sendChatChecked(msg.to, msg_id)
                        samudra5.sendChatChecked(msg.to, msg_id)

                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               samudra.sendMessage(msg.to, str(helpMessage))

                        if cmd == "self on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                samudra.sendMessage(msg.to, "Selfbot active")

                        elif cmd == "self off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                samudra.sendMessage(msg.to, "Selfbot not active")

                        elif cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpbot()
                               samudra.sendMessage(msg.to, str(helpMessage1))

                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"
                                if wait["sticker"] == True: md+="❧Sticker「ON」\n"
                                else: md+="❧Sticker「OFF」\n"
                                if wait["contact"] == True: md+="❧Contact「ON」\n"
                                else: md+="❧Contact「OFF」\n"
                                if wait["talkban"] == True: md+="❧Talkban「ON」\n"
                                else: md+="❧Talkban「OFF」\n"
                                if wait["Mentionkick"] == True: md+="❧Notag���ON」\n"
                                else: md+="❧Notag「OFF���\n"
                                if wait["detectMention"] == True: md+="❧Respon「ON」\n"
                                else: md+="❧Respon「OFF」\n"
                                if wait["autoJoin"] == True: md+="❧Autojoin「ON」\n"
                                else: md+="❧Autojoin「OFF」\n"
                                if wait["autoAdd"] == True: md+="❧Autoadd「ON」\n"
                                else: md+="❧Autoadd「OFF」\n"
                                if msg.to in welcome: md+="❧Welcome「ON」\n"
                                else: md+="❧Welcome「OFF」\n"
                                if wait["autoLeave"] == True: md+="❧Autoleave「ON」\n"
                                else: md+="❧Autoleave「OFF」\n"
                                if msg.to in protectqr: md+="❧Protecturl「ON」\n"
                                else: md+="❧Protecturl「OFF」\n"
                                if msg.to in protectjoin: md+="❧Protectjoin「ON」\n"
                                else: md+="❧Protectjoin「OFF」\n"
                                if msg.to in protectkick: md+="❧Protectkick「ON」\n"
                                else: md+="❧Protectkick「OFF」\n"
                                if msg.to in protectinvite: md+="❧Protectinvite「ON」\n"
                                else: md+="❧Protectinvite「OFF」\n"
                                if msg.to in protectcancel: md+="❧Protectcancel「ON」\n"
                                else: md+="❧Protectcancel「OFF」\n"
                                if msg.to in protectantijs: md+="❧Antijs「ON」\n"
                                else: md+="❧Antijs「OFF」\n"
                                samudra.sendMessage(msg.to, md+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                samudra.sendText(msg.to,"Creator : bang samudra\nsamudrabots.py")
                                ma = ""
                                for i in creator:
                                    ma = samudra.getContact(i)
                                    samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention(msg.to, sender, "「 Type Selfbot 」\n")
                               samudra.sendMessage(msg.to, None, contentMetadata={'mid': selfmid}, contentType=13)

                        elif cmd == "me" or text.lower() == 'aim':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               samudra.sendMessage(to, "team ﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿")
                               samudra.sendMessage(msg.to, None, contentMetadata= jiranstick["saya"], contentType=7)

                        elif text.lower() == "mid":
                               samudra.sendMessage(msg.to, msg._from)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = samudra.getContact(key1)
                               samudra.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               samudra.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = samudra.getContact(key1)
                               samudra.sendMessage(msg.to, "❧Nama : "+str(mi.displayName)+"\n❧Mid : " +key1+"\n❧Status Msg"+str(mi.statusMessage))
                               samudra.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(samudra.getContact(key1)):
                                   samudra.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   samudra.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif text.lower() == "hapus mantan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   samudra.removeAllMessages(op.param2)
                                   samudra.sendMessage(msg.to,"Mantan Dimusnahkan...!")
                               except:
                                   pass

                        elif text.lower() == "hapus selingkuhan":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   samudra1.removeAllMessages(op.param2)
                                   samudra2.removeAllMessages(op.param2)
                                   samudra3.removeAllMessages(op.param2)
                                   samudra4.removeAllMessages(op.param2)
                                   samudra5.removeAllMessages(op.param2)
                                   samudra1.sendMessage(msg.to,"Selingkuhan Dibinasakan...")
                                   samudra2.sendMessage(msg.to,"Selingkuhan Dibuang...")
                                   samudra3.sendMessage(msg.to,"Selingkuhan Mampus...")
                                   samudra4.sendMessage(msg.to,"Selingkuhan Wafat ...")
                                   samudra5.sendMessage(msg.to,"Selingkuhan Dikubur wkwkwk Padahal Owner Botnya Doyan Selingkuh🤣...!")
                               except:
                                   pass

                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = samudra.getGroupIdsJoined()
                               for group in saya:
                                   samudra.sendMessage(group,"[ Broadcast ]\n" + str(pesan))

                        elif cmd.startswith("inviteme"):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               saya = samudra.getGroupIdsJoined()
                               for group in saya:
                                   samudra.inviteIntoGroup(group,["mid"])

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   samudra.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   samudra.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               samudra.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "Tunggu sebentar...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               samudra.sendMessage(msg.to, "Silahkan gunakan seperti semula...")

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               samudra.sendMessage(msg.to,bot)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = samudra.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(samudra.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                samudra.sendMessage(msg.to, "Grup Info\n\n❧Nama Group : {}".format(G.name)+ "\n❧ID Group : {}".format(G.id)+ "\n❧Pembuat : {}".format(G.creator.displayName)+ "\n❧Waktu Dibuat : {}".format(str(timeCreated))+ "\n❧Jumlah Member : {}".format(str(len(G.members)))+ "\n❧Jumlah Pending : {}".format(gPending)+ "\n❧Group Qr : {}".format(gQr)+ "\n❧Group Ticket : {}".format(gTicket))
                                samudra.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                samudra.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                samudra.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(samudra.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "❧Info Grup\n"
                                ret_ += "\n❧Nama Group : {}".format(G.name)
                                ret_ += "\n❧ID Group : {}".format(G.id)
                                ret_ += "\n❧Pembuat : {}".format(gCreator)
                                ret_ += "\n❧Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n❧Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n❧Jumlah Pending : {}".format(gPending)
                                ret_ += "\n❧Group Qr : {}".format(gQr)
                                ret_ += "\n❧Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                samudra.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = samudra.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "❧"+ str(no) + ". " + mem.displayName
                                samudra.sendMessage(to,"❧Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except:
                                pass

                        elif cmd == "myfriend":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra.getAllContactIds()
                               for i in gid:
                                   G = samudra.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra1.getAllContactIds()
                               for i in gid:
                                   G = samudra1.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra1.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra2.getAllContactIds()
                               for i in gid:
                                   G = samudra2.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra2.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend3":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra3.getAllContactIds()
                               for i in gid:
                                   G = samudra3.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra3.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend4":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra4.getAllContactIds()
                               for i in gid:
                                   G = samudra4.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra4.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend5":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra5.getAllContactIds()
                               for i in gid:
                                   G = samudra5.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               samudra5.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = samudra.getGroupIdsJoined()
                               for i in gid:
                                   G = samudra.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               samudra.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = samudra.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   samudra.updateGroup(X)
                                   samudra.sendMessage(msg.to, "Url Opened")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = samudra.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   samudra.updateGroup(X)
                                   samudra.sendMessage(msg.to, "Url Closed")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = samudra.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      samudra.updateGroup(x)
                                   gurl = samudra.reissueGroupTicket(msg.to)
                                   samudra.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                samudra.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                samudra1.sendMessage(msg.to,"please send new photo.....")
                                samudra2.sendMessage(msg.to,"please send new photo.....")
                                samudra3.sendMessage(msg.to,"please send new photo.....")
                                samudra4.sendMessage(msg.to,"please send new photo.....")
                                samudra5.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "updatefoto":
                            if msg._from in admin:
                                Setmain["ARfoto"][selfmid] = True
                                samudra.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot1up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Amid] = True
                                samudra1.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot2up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Bmid] = True
                                samudra2.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot3up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Cmid] = True
                                samudra3.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot4up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Dmid] = True
                                samudra4.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot5up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Emid] = True
                                samudra5.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "js1up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Xmid] = True
                                samudrajs1.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "js2up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Zmid] = True
                                samudrajs2.sendMessage(msg.to,"please send new photo.....")

                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra.getProfile()
                                profile.displayName = string
                                samudra.updateProfile(profile)
                                samudra.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot1name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra1.getProfile()
                                profile.displayName = string
                                samudra1.updateProfile(profile)
                                samudra1.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot2name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra2.getProfile()
                                profile.displayName = string
                                samudra2.updateProfile(profile)
                                samudra2.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot3name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra3.getProfile()
                                profile.displayName = string
                                samudra3.updateProfile(profile)
                                samudra3.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot4name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra4.getProfile()
                                profile.displayName = string
                                samudra4.updateProfile(profile)
                                samudra4.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot5name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudra5.getProfile()
                                profile.displayName = string
                                samudra5.updateProfile(profile)
                                samudra5.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("js1name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudrajs1.getProfile()
                                profile.displayName = string
                                samudrajs1.updateProfile(profile)
                                samudrajs1.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("js2name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = samudrajs2.getProfile()
                                profile.displayName = string
                                samudrajs2.updateProfile(profile)
                                samudrajs2.sendMessage(msg.to,"Name change to " + string + "")

#===========BOT UPDATE============#
                        elif msg.text in ["sayang","sepi","cinta","cipok","hadir"]:
                               if wait["selfbot"] == True:
                                if msg._from in admin:
                                 group = samudra.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Zero \n'
                                    samudra.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Semeton:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to,"❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n\n"+ma+"\nTotal「%s」 Bots" %(str(len(Semeton))))

                        elif cmd == "adminlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +samudra.getContact(m_id).displayName + "\n"
                                for m_id in zeuszxadmin["staff"]:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to,"♻﴾ ᴅᴀғтᴀʀ ᴀᴅмιɴ ﴿♻ \n\nSuper admin: sᴀмuᴅʀᴀ\nAdmin:\n"+mb+"\nStaff:\n"+mc+"\nTotal「%s」 Anggota" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                mf = ""
                                a = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mb += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    md += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mc += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                gid = protectinvite
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    me += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                gid = protectantijs
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mf += str(a) + ". " +samudra.getGroup(group).name + "\n"
                                samudra.sendMessage(msg.to,"「♻﴾ sᴀмuᴅʀᴀ ᴘʀoтᴇcтιoɴ ﴿♻」\n\n「✭」 PROTECT URL :\n"+ma+"\n「✭」 PROTECT KICK :\n"+mb+"\n「✭」 PROTECT JOIN :\n"+md+"\n「✭」 PROTECT CANCEL:\n"+mc+"\n「✭」 PROTECT INVITE:\n"+me+"\n「✭」 PROTECT ANTIJS :\n"+mf+"\nTotal「%s」Grup diamankan" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite)+len(protectantijs))))

                        elif cmd == "absen" or cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["qr"] = False
                                wait["inv"] = False
                                samudra1.sendMessage(msg.to, "(❁´sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")
                                samudra2.sendMessage(msg.to, "(❁´sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")
                                samudra3.sendMessage(msg.to, "(❁´sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")
                                samudra4.sendMessage(msg.to, "(❁´sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")
                                samudra5.sendMessage(msg.to, "(❁´sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")

                        elif cmd == "jsabsen" or cmd == "jsrespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["qr"] = False
                                samudrajs1.sendMessage(msg.to, "(❁´Js~sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")
                                samudrajs2.sendMessage(msg.to, "(❁´Js~sмuᴅʀᴀ___ʙoтs нᴀᴅιʀ ʙosκιuuu`❁)")


                        elif cmd == "invite":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid,Bmid,Cmid,Dmid,Emid]
                                    samudra.inviteIntoGroup(msg.to, anggota)
                                    samudra1.acceptGroupInvitation(msg.to)
                                    samudra2.acceptGroupInvitation(msg.to)
                                    samudra3.acceptGroupInvitation(msg.to)
                                    samudra4.acceptGroupInvitation(msg.to)
                                    samudra5.acceptGroupInvitation(msg.to)
                                except:
                                    pass

                        elif cmd == "js stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    samudra.findAndAddContactsByMid(Xmid)
                                    samudra.findAndAddContactsByMid(Zmid)
                                    samudra.inviteIntoGroup(msg.to, [Xmid,Zmid])
                                    samudra.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 save")
                                except:
                                    pass

                        elif cmd == "in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                ginfo = samudra.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                Ticket = samudra.reissueGroupTicket(msg.to)
                                samudra1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                samudra2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                samudra3.acceptGroupInvitationByTicket(msg.to,Ticket)
                                samudra4.acceptGroupInvitationByTicket(msg.to,Ticket)
                                samudra5.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = samudra5.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                samudra5.updateGroup(G)
                                ginfo = samudra.getGroup(msg.to)
                                samudra.inviteIntoGroup(msg.to, [Xmid,Zmid])

                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                samudra.cancelGroupInvitation(msg.to, [Xmid])
                                samudra.cancelGroupInvitation(msg.to, [Zmid])
                                samudra1.leaveGroup(msg.to)
                                samudra2.leaveGroup(msg.to)
                                samudra3.leaveGroup(msg.to)
                                samudra4.leaveGroup(msg.to)
                                samudra5.leaveGroup(msg.to)


                        elif cmd == "byeme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                samudra.leaveGroup(msg.to)

                        elif cmd == "leaveall":
                            if msg._from in admin:
                                gid = random.choice(SASAK).getGroupIdsJoined()
                                for i in gid:
                                    samudra.sendMessage(i, "please contact my creator")
                                    samudra.leaveGroup(i)
                                    samudra1.leaveGroup(i)
                                    samudra2.leaveGroup(i)
                                    samudra3.leaveGroup(i)
                                    samudra4.leaveGroup(i)
                                    samudra5.leaveGroup(i)

                        elif cmd == "js in":
                            if msg._from in admin:
                                G = samudra.getGroup(msg.to)
                                ginfo = samudra.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                samudra.updateGroup(G)
                                invsend = 0
                                Ticket = samudra.reissueGroupTicket(msg.to)
                                samudrajs1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                samudrajs2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = samudrajs2.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                samudrajs2.updateGroup(G)

                        elif cmd == "js out":
                            if msg._from in admin:
                                samudrajs1.leaveGroup(msg.to)
                                samudrajs2.leaveGroup(msg.to)

                        elif cmd == "sprespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = samudra.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = samudra.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = samudra.getContact(selfmid)
                                get_contact_time = time.time() - get_contact_time_start
                                samudra.sendMessage(msg.to, "❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿ Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == "mysp" or cmd == "myspeed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               get_group_time_start = time.time()
                               get_group = samudra.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra.sendMessage(msg.to, "%s secc" % (get_group_time))

                        elif cmd == "sp" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               get_group_time_start = time.time()
                               get_group = samudra1.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra1.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = samudra2.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra2.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = samudra3.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra3.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = samudra4.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra4.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = samudra5.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               samudra5.sendMessage(msg.to, "%s secc" % (get_group_time))

                        elif cmd == "lurking on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['ARreadPoint'][msg.to] = msg_id
                                 Setmain['ARreadMember'][msg.to] = {}
                                 samudra.sendText(msg.to, "Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurking off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['ARreadPoint'][msg.to]
                                 del Setmain['ARreadMember'][msg.to]
                                 samudra.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['ARreadPoint']:
                                if Setmain['ARreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['ARreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(samudra.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        samudra.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['ARreadPoint'][msg.to]
                                        del Setmain['ARreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['ARreadPoint'][msg.to] = msg.id
                                    Setmain['ARreadMember'][msg.to] = {}
                                else:
                                    samudra.sendText(msg.to, "User kosong...")
                            else:
                                samudra.sendText(msg.to, "Ketik lurking on dulu")

                        elif cmd == "ciluk ba":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  samudra.sendMessage(msg.to, "sider actif\n\ndate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nclock [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "colok ni":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  samudra.sendMessage(msg.to, "sider not actif\n\ndate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nclock [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  samudra.sendMessage(msg.to, "not active")
#===========Hiburan============#
                        elif cmd.startswith("spamtag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["ARlimit"] = num
                                samudra.sendMessage(msg.to,"now spamtag " +strnum)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                samudra.sendMessage(msg.to,"now spamcall " +strnum)
#----Sticker--------------------------------------------------------------------
                        elif cmd.startswith("setsticker "):
                          if msg._from in admin:
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ","")
                            name = name.lower()
                            if name in jiranstick:
                                wait["setsticker"]["status"] = True
                                wait["setsticker"]["name"] = str(name.lower())
                                jiranstick[str(name.lower())] = ""
                                f = codecs.open('sticker4.json','w','utf-8')
                                json.dump(jiranstick, f, sort_keys=True, indent=4, ensure_ascii=False)
                                samudra.sendMessage(to, "Silahkan kirim stiker yang ingin anda ubah")
                            else:
                                samudra.sendMessage(to, "Stiker tidak ada dalam list")
#-------------------------------------------------------------------------------
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                samudra.sendMessage(msg)
                                            except Exception as e:
                                                samudra.sendMessage(msg.to,str(e))
                                    else:
                                        samudra.sendMessage(msg.to,"Jumlah melebihi 1000")

                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = samudra.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                samudra.sendMessage(msg.to, "succes invite {} Call Grup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        samudra.sendMessage(msg.to,str(e))
                                else:
                                    samudra.sendText(msg.to,"Jumlah melebihi batas")

                        elif 'Spam ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[15])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      samudra.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      samudra1.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      samudra2.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      samudra3.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      samudra4.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      samudra5.sendMessage(midd, str(Setmain["ARmessage1"]))

                        elif 'Id line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('Id line: ','')
                              conn = samudra.findContactsByUserid(msgs)
                              if True:
                                  samudra.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  samudra.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    samudra.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url active"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Protect url active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Protect url not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick active"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Protect kick active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Protect kick not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite active"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Protect invite active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Protect invite not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join active"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Protect join active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Protect join not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel active"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Protect cancel active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Protect cancel not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Antijs ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Antijs ','')
                              if spl == 'on':
                                  if msg.to in protectantijs:
                                       msgs = "Anti JS active"
                                  else:
                                       protectantijs.append(msg.to)
                                       ginfo = samudra.getGroup(msg.to)
                                       msgs = "Anti JS active\nin Group : " +str(ginfo.name)
                                  samudra.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Anti JS not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Anti JS not active"
                                    samudra.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Allpro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Allpro ','')
                              if spl == 'on':
                                #if wait["allprotect"] == True:
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(msg.to)
                                  if msg.to in protectantijs:
                                      msgs = ""
                                  else:
                                      protectantijs.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = samudra.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nin Group : " +str(ginfo.name)
                                      msgs += "\nAll protection active"
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = samudra.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nin Group : " +str(ginfo.name)
                                      msgs += "\nAll protection active"
                                  samudra.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)
                              elif spl == 'off':
                                 #if wait["allprotect"] == False:
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nin Group : " +str(ginfo.name)
                                         msgs += "\nAll protection not active"
                                    else:
                                         ginfo = samudra.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nin Group : " +str(ginfo.name)
                                         msgs += "\nAll protection not active"
                                    samudra.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)

#===========KICKOUT============#
                        elif ("Kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Semeton:
                                       try:
                                           random.choice(LOMBOK).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Vkick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                nk0 = msg.text.replace("Vkick ","")
                                nk1 = nk0.lstrip()
                                nk2 = nk1.replace("@","")
                                nk3 = nk2.rstrip()
                                _name = nk3
                                gs = random.choice(LOMBOK).getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    pass
                                else:
                                    for target in targets:
                                        if target in Semeton and target in admin:
                                            pass
                                        else:
                                            try:
                                                wait["blacklist"][target] = True
                                                random.choice(LOMBOK).kickoutFromGroup(msg.to,[target])
                                            except:
                                                pass

                        elif ("Nk " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                nk0 = msg.text.replace("Nk ","")
                                nk1 = nk0.lstrip()
                                nk2 = nk1.replace("@","")
                                nk3 = nk2.rstrip()
                                _name = nk3
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    pass
                                else:
                                    for target in targets:
                                        if target in Semeton and target in admin:
                                            pass
                                        else:
                                            try:
                                                G = samudra.getGroup(msg.to)
                                                G.preventedJoinByTicket = False
                                                samudra.updateGroup(G)
                                                Ticket = samudra.reissueGroupTicket(msg.to)
                                                samudrajs2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                                samudrajs2.kickoutFromGroup(msg.to,[target])
                                                samudrajs2.leaveGroup(msg.to)
                                                G = samudra.getGroup(msg.to)
                                                G.preventedJoinByTicket = True
                                                samudra.updateGroup(G)
                                                samudra.inviteIntoGroup(msg.to,[Zmid])
                                            except:
                                                pass

                        elif cmd == "clean" or text.lower() == 'clean':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                group = random.choice(LOMBOK).getGroup(msg.to)
                                sundel = [contact.mid for contact in group.invitee]
                                ubek = [contact.mid for contact in group.members]
                                for tele in ubek:
                                    if tele not in Semeton and tele not in owner and tele not in admin and tele not in staff:
                                        try:
                                            klist = [samudra1,samudra2,samudra3,samudra4,samudra5]
                                            pepek = random.choice(klist)
                                            pepek.getContact(kampret).mid
                                            pepek.cancelGroupInvitation(msg.to, [tele])
                                        except:
                                            pass
                                for telor in sundel:
                                    if telor not in Semeton and telor not in owner and telor not in admin and telor not in staff:
                                        try:
                                            klist = [samudra1,samudra2,samudra3,samudra4,samudra5]
                                            pepek = random.choice(klist)
                                            pepek.getContact(telor).mid
                                            pepek.kickoutFromGroup(msg.to, [telor])
                                        except:
                                            pass

                        elif cmd == "cancelall" or text.lower() == 'cancelall':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                group = random.choice(LOMBOK).getGroup(msg.to)
                                ubek = [contact.mid for contact in group.invitee]
                                for tele in ubek:
                                    if tele not in Semeton and tele not in owner and tele not in admin and tele not in staff:
                                        try:
                                            klist = [samudra1,samudra2,samudra3,samudra4,samudra5]
                                            pepek = random.choice(klist)
                                            pepek.getContact(tele).mid
                                            pepek.cancelGroupInvitation(msg.to, [tele])
                                        except:
                                            pass
#===========ADMIN ADD============#
                        elif ("Add " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           samudra.findAndAddContactsByMid(target)
                                           samudra1.findAndAddContactsByMid(target)
                                           samudra2.findAndAddContactsByMid(target)
                                           samudra3.findAndAddContactsByMid(target)
                                           samudra4.findAndAddContactsByMid(target)
                                           samudra5.findAndAddContactsByMid(target)
                                           samudra.sendMessage(msg.to,"succes add friend")
                                           samudra1.sendMessage(msg.to,"succes add friend")
                                           samudra2.sendMessage(msg.to,"succes add friend")
                                           samudra3.sendMessage(msg.to,"succes add friend")
                                           samudra4.sendMessage(msg.to,"succes add friend")
                                           samudra5.sendMessage(msg.to,"succes add friend")
                                       except:
                                           pass

                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           samudra.sendMessage(msg.to,"succes add admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           zeuszxadmin["staff"][target] = True
                                           f=codecs.open('zeuszxadmin.json','w','utf-8')
                                           json.dump(famzadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           samudra.sendMessage(msg.to,"Succes add staff")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Semeton.append(target)
                                           samudra.sendMessage(msg.to,"Berhasil menambahkan bot")
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           admin.remove(target)
                                           samudra.sendMessage(msg.to,"succes remove admin")
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           del zeiszxadmin["staff"][target]
                                           f=codecs.open('zeuszxadmin.json','w','utf-8')
                                           json.dump(zeuszxadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           samudra.sendMessage(msg.to,"Succes remove staff")
                                       except:
                                           pass

                        elif ("Botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           Semeton.remove(target)
                                           samudra.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                samudra.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                samudra.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                samudra.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                samudra.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                samudra.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                wait["qr"] = False
                                wait["inv"] = False
                                samudra.sendMessage(msg.to,"succes to Refresh...")

                        elif cmd == "listadmin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = samudra.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                for i in zeuszxadmin["staff"]:
                                    ma = samudra.getContact(i)
                                    samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "mybot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Semeton:
                                    ma = samudra.getContact(i)
                                    samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                samudra.sendMessage(msg.to,"Notag diaktifkan")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                samudra.sendMessage(msg.to,"Notag dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                samudra.sendMessage(msg.to,"Detect contact active")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                samudra.sendMessage(msg.to,"Detect contact not active")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                samudra.sendMessage(msg.to,"Auto respon active")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                samudra.sendMessage(msg.to,"Auto respon not active")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                cl.sendMessage(msg.to,"Autojoin active")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                samudra.sendMessage(msg.to,"Autojoin not active")
#-------------------------------------------------------------------------------------
                        elif cmd == "left on" or text.lower() == 'left on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["left"] = True
                                samudra.sendMessage(msg.to,"leave message active")

                        elif cmd == "left off" or text.lower() == 'left off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["left"] = False
                                samudra.sendMessage(msg.to,"leave message not active")
#----------------------------------------------------------------------------------------
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                samudra.sendMessage(msg.to,"Autoleave diaktifkan")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                samudra.sendMessage(msg.to,"Autoleave dinonaktifkan")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                samudra.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                samudra.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "read on" or text.lower() == 'autoread on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                samudra.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "read off" or text.lower() == 'autoread off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                samudra.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                samudra.sendMessage(msg.to,"Deteksi sticker diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                samudra.sendMessage(msg.to,"Deteksi sticker dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                samudra.sendMessage(msg.to,"Join ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                samudra.sendMessage(msg.to,"Autojoin Tiket dinonaktifkan")
#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           samudra.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           samudra.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                samudra.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                samudra.sendMessage(msg.to,"Kirim kontaknya...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           samudra.sendMessage(msg.to,"succes add blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           samudra.sendMessage(msg.to,"succes remove blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                samudra.sendMessage(msg.to,"send contact...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                samudra.sendMessage(msg.to,"send contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                samudra.sendMessage(msg.to,"have't blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to,"﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿ Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                                wait["qr"] = False
                                wait["inv"] = False

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                samudra.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +samudra.getContact(m_id).displayName + "\n"
                                samudra.sendMessage(msg.to,"❧ĐPĶ Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    samudra.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = samudra.getContact(i)
                                        samudra.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "ceban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = samudra.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              wait["qr"] = False
                              wait["inv"] = False
                              samudra.sendMessage(msg.to,"Clearrrr....!!! ")
                              samudra1.sendMessage(msg.to,"Clearrrr....!!! ")
                              samudra2.sendMessage(msg.to,"Clearrrr....!!! ")
                              samudra3.sendMessage(msg.to,"Clearrrr....!!! ")
                              samudra4.sendMessage(msg.to,"Clearrrr....!!! ")
                              samudra5.sendMessage(msg.to,"Clearrrr....!!! ")

                        elif text.lower() == "cekbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:samudra.inviteIntoGroup(to, [selfmid]);has = "OK"
                                except:has = "NOT"
                                try:samudra.kickoutFromGroup(to, [selfmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:samudra1.inviteIntoGroup(to, [Amid]);has = "OK"
                                except:has = "NOT"
                                try:samudra1.kickoutFromGroup(to, [Amid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra1.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:samudra2.inviteIntoGroup(to, [Bmid]);has = "OK"
                                except:has = "NOT"
                                try:samudra2.kickoutFromGroup(to, [Bmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra2.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:samudra3.inviteIntoGroup(to, [Cmid]);has = "OK"
                                except:has = "NOT"
                                try:samudra3.kickoutFromGroup(to, [Cmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra3.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:samudra4.inviteIntoGroup(to, [Dmid]);has = "OK"
                                except:has = "NOT"
                                try:samudra4.kickoutFromGroup(to, [Dmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra4.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:samudra5.inviteIntoGroup(to, [Emid]);has = "OK"
                                except:has = "NOT"
                                try:samudra5.kickoutFromGroup(to, [Emid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                samudra5.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  samudra.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  samudra.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti leave Msg")
                              else:
                                  wait["leave"] = spl
                                  samudra.sendMessage(msg.to, "「leave Msg」\leave Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  samudra.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["ARmessage1"] = spl
                                  samudra.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  samudra.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  samudra.sendMessage(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(Setmain["ARmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               samudra.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = samudra.findGroupByTicket(ticket_id)
                                     samudra.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     samudra.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group1 = samudra1.findGroupByTicket(ticket_id)
                                     samudra1.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     samudra1.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group2 = samudra2.findGroupByTicket(ticket_id)
                                     samudra2.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     samudra2.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group3 = samudra3.findGroupByTicket(ticket_id)
                                     samudra3.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     samudra3.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group4 = samudra4.findGroupByTicket(ticket_id)
                                     samudra4.acceptGroupInvitationByTicket(group4.id,ticket_id)
                                     samudra4.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group5 = samudra5.findGroupByTicket(ticket_id)
                                     samudra5.acceptGroupInvitationByTicket(group5.id,ticket_id)
                                     samudra5.sendMessage(msg.to, "Masuk : %s" % str(group.name))
    except Exception as error:
        print (error)

while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        print(e)















